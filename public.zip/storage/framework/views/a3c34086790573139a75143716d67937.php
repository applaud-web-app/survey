<table>
    <thead>
    <tr>
        <th>Timestamp</th>
        <?php $__currentLoopData = $question_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($item->question); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
   
        <?php $__currentLoopData = $surveyAnsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(date("d M Y H:i A",strtotime($item->created_at))); ?></td>
            <?php $__currentLoopData = $item->survey_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($val->answer); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\survey\resources\views/admin/feedback/survey-export.blade.php ENDPATH**/ ?>