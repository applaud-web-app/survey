
<?php $__env->startSection('section'); ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <section class="relative content-body">
        <div class="container mx-auto ">
            <div class="flex items-center justify-between flex-wrap mb-5">
                <div class="items-center ">
                    <h1 class="md:text-3xl text-2xl md:mb-0 mb-3 block dark:text-slate-100"><?php echo e($surveyData->survey_title); ?></h1>
                </div>
            </div>
            <div class="mb-4 border-b bg-white border-gray-200 dark:border-slate-700">
                <ul class="flex flex-wrap -mb-px  font-medium text-center">
                    <li class="w-1/2">

                        <a href="<?php echo e($summary_link); ?>"
                            class="inline-block p-4 w-full rounded-t-lg border-b-2 border-transparent text-gray-500 hover:text-gray-600 dark:text-gray-400 border-gray-100 hover:border-gray-300 dark:border-gray-700 dark:hover:text-gray-300"
                            ><i class="fa-solid fa-clipboard"></i>
                            Summary</a>

                       
                    </li>

                    <li class="w-1/2">
                        <a href="<?php echo e($individual_link); ?>"
                        class="inline-block p-4 w-full rounded-t-lg border-b-2 text-blue-600 hover:text-blue-600 dark:text-blue-500 dark:hover:text-blue-400 border-blue-600 dark:border-blue-500"><i class="fa-regular fa-rectangle-list"></i>
                        Individual</a>
                    </li>

                </ul>
            </div>

            <div>
                <div>
                    <div >
                        <div class="mb-5">
                            <?php echo e($surveyIndividual->onEachSide(50)->appends(request()->input())->links('custom-pagination')); ?>

                        </div>
    
                        <div class="card">
                            <div class="card-body">
                                <?php if(isset($surveyIndividual[0])): ?>
                                <h4 class="text-lg">ID: <?php echo e($surveyIndividual[0]->id); ?></h4>
                                <h5 class="text-sm">Email: <?php echo e($surveyIndividual[0]->email!=null ? $surveyIndividual[0]->email : '-'); ?></h5>
                                <?php endif; ?>
                                <hr class="mt-3">
                                <ul role="list" class="divide-y space-y-3  divide-gray-200 dark:divide-gray-700">
                                    <?php
                                        $i=1
                                    ?>
                                    <?php $__currentLoopData = $surveyIndividual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $value->survey_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="py-3 bg-gray-50 p-3">
                                                <p class=" font-medium text-gray-900 truncate dark:text-white">
                                                    <b><?php echo e($i); ?>.</b> <?php echo e($item->question); ?>

                                                </p>
                                                <p class="text-sm text-gray-500 truncate dark:text-gray-400">
                                                    <?php echo e($item->answer); ?>

                                                </p>
                                            </li>
                                            <?php
                                                $i++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </ul>
                            </div>
    
                        </div>
                    </div>
    
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8\htdocs\feedback\resources\views/admin/feedback/survey-response-individual.blade.php ENDPATH**/ ?>