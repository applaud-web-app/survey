
<?php $__env->startSection('section'); ?>

<section class="relative content-body">
    <div class="container mx-auto ">
        <div class="w-full md:w-full lg:w-2/3 xl:w-2/3 mx-auto">
            <div class=" p-3 mb-3 bg-[#091734]  rounded-sm">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="mx-auto w-[260px] ">
            </div>
            <div class="mb-4 title-card">
                <h1 class="text-3xl mb-3"><?php echo e($feedbackData->survey_title); ?></h1>
                <h5 class="text-lg mb-1">Category: <span class="text-blue-500"><?php echo e($feedbackData->category->category_name); ?></h5>
                <p class="text-lg"><?php echo e($feedbackData->description); ?></p>
            </div>
            <div class="flex space-x-3">
                <div class="w-1/2">
                    <a href="<?php echo e($nextLink); ?>" class="text-white  text-center bg-blue-500 hover:bg-blue-600 focus:ring-2 focus:ring-blue-300 font-medium rounded  px-3 py-2  dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none dark:focus:ring-blue-700">Next <i class="fa-solid fa-chevron-right"></i></a>
                </div>
                <div class="w-1/2 flex items-center ">
                    <div class="w-full me-3">
                        <div class="w-full bg-gray-200 rounded-full dark:bg-gray-700">
                            <div class="bg-blue-500 text-xs font-medium text-blue-100 text-center p-0.5 leading-none rounded-full" style="width: 33%"> 33%</div>
                        </div>
                    </div>
                    <div class="whitespace-nowrap ms-3">
                        <p>Page 1 of 3</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.single-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-8\htdocs\feedback\resources\views/index/feedback.blade.php ENDPATH**/ ?>